// com/example/monitoragricola/jobs/JobEventType.kt
package com.example.monitoragricola.jobs

enum class JobEventType { START, PAUSE, RESUME, FINISH, CANCEL, SIGNAL_LOST, SIGNAL_BACK, REOPENED_FROM }
