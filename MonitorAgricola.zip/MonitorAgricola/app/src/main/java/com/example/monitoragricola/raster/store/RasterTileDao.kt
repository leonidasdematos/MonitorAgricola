// com/example/monitoragricola/raster/store/RasterTileDao.kt
package com.example.monitoragricola.raster.store

import androidx.room.*

data class RasterTileRow(
    val rev: Int,
    val layerMask: Int,
    val payload: ByteArray
)

data class RasterTileCoord(
    val tx: Int,
    val ty: Int
)


@Dao
interface RasterTileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTiles(tiles: List<RasterTileEntity>)

    @Query("SELECT * FROM raster_tiles WHERE jobId = :jobId AND tx = :tx AND ty = :ty LIMIT 1")
    suspend fun getTile(jobId: Long, tx: Int, ty: Int): RasterTileEntity?

    @Query("SELECT COUNT(*) FROM raster_tiles WHERE jobId = :jobId")
    suspend fun countByJob(jobId: Long): Int

    @Query("SELECT tx, ty FROM raster_tiles WHERE jobId = :jobId")
    suspend fun listCoords(jobId: Long): List<RasterTileCoord>

    @Query("DELETE FROM raster_tiles WHERE jobId = :jobId")
    suspend fun deleteByJob(jobId: Long)
}
