// com/example/monitoragricola/jobs/JobState.kt
package com.example.monitoragricola.jobs

enum class JobState { ACTIVE, PAUSED, COMPLETED, CANCELED }