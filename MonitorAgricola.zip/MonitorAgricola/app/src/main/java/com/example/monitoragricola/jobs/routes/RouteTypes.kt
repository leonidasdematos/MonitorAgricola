// com/example/monitoragricola/jobs/routes/RouteTypes.kt
package com.example.monitoragricola.jobs.routes

enum class RouteType { AB_STRAIGHT, AB_CURVE }
enum class RouteState { DRAFT, ACTIVE, ARCHIVED }
